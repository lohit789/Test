
var naviMenu = 
{
	"naviItems": [
		// "id": <ID>, "props": <NAME>|<ICON>|<LINK>
		{
			"id": "Dashboard", "props": "Dashboard|icon-home|javascript:;",
			"subNaviItems": [
				{ "id": "SystemDashboard", "props": "Sensor Network|fa fa-dashboard|SystemDashboard.html" }
			]
		},
		{
			"id": "PlatformManagement", "props": "Platform Management|fa fa-server|javascript:;",
			"subNaviItems": [
				{ "id": "HostMonitoring", "props": "Host Monitoring|fa fa-hdd-o|HostMonitoring.html" },
				{ "id": "AppMonitoring", "props": "Application Monitoring|fa fa-laptop|AppMonitoring.html" }
			]
		},
		{
			"id": "Inventory", "props": "Inventory|fa fa-th-list|javascript:;",
			"subNaviItems": [
				{ "id": "SensorGateways", "props": "Sensor Gateways|fa fa-reorder|SensorGatewayList.html" },
				{ "id": "SensorNodes", "props": "Sensor Nodes|fa fa-reorder|SensorNodeList.html" },
				{ "id": "Sensors", "props": "Sensors|fa fa-reorder|SensorList.html" }
			]
		},
		{
			"id": "DeviceGroups", "props": "Device Groups|fa fa-object-group|DeviceGroupList.html"
		},
		{
			"id": "Fault", "props": "Fault|fa fa-list-alt|javascript:;",
			"subNaviItems": [
				{ "id": "Events", "props": "Events|fa fa-calendar|EventList.html" },
				{ "id": "Alarms", "props": "Alarms|fa fa-bell|AlarmList.html" }
			]
		},
		{
			"id": "Maps", "props": "Maps|fa fa-map|javascript:;",
			"subNaviItems": [
				{ "id": "GoogleMap", "props": "GIS View|fa fa-globe|GISView.html" }
			]
		},
		{
			"id": "DataLogger", "props": "Data Logger|fa fa-server|javascript:;",
			"subNaviItems": [
				{ "id": "GalaxyNetwork", "props": "Galaxy Network|fa fa-empire|DataLoggerGalaxy.html" },
				{ "id": "LoRaNetwork", "props": "LoRa Network|fa fa-pencil-square-o|DataLoggerLoRa.html" }
			]
		},
		{
			"id": "Admin", "props": "Administration|fa fa-gear|javascript:;",
			"subNaviItems": [
				{ "id": "Users", "props": "Users|icon-users|UserList.html" },
				{ "id": "UserGroups", "props": "User Groups|fa fa-group|UserGroupList.html" },
				{ "id": "Applications", "props": "Applications|fa fa-tasks|ApplicationList.html" },
				{ "id": "Tenants", "props": "Tenants|fa fa-home|TenantList.html" }
			]
		},
		{
			"id": "AuditTrail", "props": "Audit Trail|fa fa-history|AuditTrail.html"
		}
		/*,
		{
			"id": "Sandbox", "props": "Sandbox|fa fa-inbox|javascript:;",
			"subNaviItems": [
				{ "id": "BootstrapTable", "props": "Bootstrap Table|fa fa-genderless|BootstrapTable.html" }
			]
		}
		*/
	]
};

var Commons = function() {
	
	return {
		
		showNmsTitle: function() {
			var nmsTitle = "IoT MANAGEMENT PLATFORM"; // case-sensitive
			$(".titlename").text(nmsTitle);
			$(".Maintitlename").text(nmsTitle);
		},
		
		loadLogoutURL: function() {
			$("#userProfileLogout").attr("href", "Logout.do");
		},
		
		loadNaviMenuItems: function() {
			console.log(">>>>> navi menu items length: " + naviMenu.naviItems.length);

			var normalNaviMenuItems = $("#IoTNaviMenuItems_Normal");
			var mobileNaviMenuItems = $("#IoTNaviMenuItems_Mobile");

			for (var i = 0; i < naviMenu.naviItems.length; i++) {
				var naviItem = naviMenu.naviItems[i];
				var naviItemID = naviItem.id;
				var naviItemProps = naviItem.props.split("|");
				
				var normalID = naviItemID + "_NaviItem";
				var mobileID = naviItemID + "_MNaviItem";
				
				var hasSubMenu = (naviItem.subNaviItems && naviItem.subNaviItems.length > 0);
				
				// add main navigation menu items, including one for mobile version
				normalNaviMenuItems.append(createMainNaviMenuItem(normalID, naviItemProps, hasSubMenu));
				mobileNaviMenuItems.append(createMainNaviMenuItem(mobileID, naviItemProps, hasSubMenu));
				
				//console.log("----> " + naviItemID + " - sub navi menu items length: " + naviItem.subNaviItems.length);
				
				if (hasSubMenu) {
					for (var j = 0; j < naviItem.subNaviItems.length; j++) {
						var subNaviItem = naviItem.subNaviItems[j];
						var subNaviItemID = subNaviItem.id;
						var subNaviItemProps = subNaviItem.props.split("|");
						
						var subNormalID = subNaviItemID + "_NaviItem";
						var subMobileID = subNaviItemID + "_MNaviItem";
						
						// add sub navigation menu items, including one for mobile version
						$("#" + normalID + " .sub-menu").append(createSubNaviMenuItem(subNormalID, subNaviItemProps));
						$("#" + mobileID + " .sub-menu").append(createSubNaviMenuItem(subMobileID, subNaviItemProps));
					}
				}
			}
		},
		
		init: function() {
			
			this.showNmsTitle();
			this.loadLogoutURL();
			this.loadNaviMenuItems();
			
			console.log("initialized common page components... OK");
		}
		
	};
	
}();

$(document).ready(function() {
	// init common components on the page
    Commons.init();
});

function createMainNaviMenuItem(itemID, itemProps, hasSubMenu) {
	var itemText = itemProps[0];
	var itemIcon = itemProps[1];
	var itemLink = itemProps[2];
	
	var mainNaviItem = "<li id=\"" + itemID + "\" class=\"nav-item start\">";
	mainNaviItem += "<a href=\"" + itemLink + "\" class=\"nav-link" + (hasSubMenu ? " nav-toggle" : "") + "\">";
	mainNaviItem += "<i class=\"" + itemIcon + "\"></i>";
	mainNaviItem += "<span class=\"title\"> " + itemText + " </span>";
	mainNaviItem += (hasSubMenu ? "<span class=\"arrow\"></span>" : "");
	mainNaviItem += "</a>";
	mainNaviItem += (hasSubMenu ? "<ul class=\"sub-menu\"><ul>" : "");
	mainNaviItem += "</li>";
	
	return mainNaviItem;
}

function createSubNaviMenuItem(itemID, itemProps) {
	var itemText = itemProps[0];
	var itemIcon = itemProps[1];
	var itemLink = itemProps[2];
	
	var subNaviItem = "<li id=\"" + itemID + "\" class=\"nav-item\">";
	subNaviItem += "<a href=\"" + itemLink + "\" class=\"nav-link\">";
	subNaviItem += "<i class=\"" + itemIcon + "\"></i>";
	subNaviItem += "<span class=\"title\"> " + itemText + " </span>";
	subNaviItem += "</a>";
	subNaviItem += "</li>";
	
	return subNaviItem;
}

function setSelectedNaviItems(mainNaviItem, subNaviItem) {
	//console.log(">>>>> setSelectedNaviItems(). mainNaviItem: " + mainNaviItem  + ", subNaviItem: " + subNaviItem);
	
	// set active for selected normal navi menu item
    $("#" + mainNaviItem + "_NaviItem").addClass("active open");
    $("#" + mainNaviItem + "_NaviItem span.arrow").addClass("open");
    $("#" + mainNaviItem + "_NaviItem a").append("<span class='selected'></span>");
    $("#" + subNaviItem + "_NaviItem").addClass("active open");
    
    // set active for selected mobile navi menu item
    $("#" + mainNaviItem + "_MNaviItem").addClass("active open");
    $("#" + mainNaviItem + "_MNaviItem span.arrow").addClass("open");
    $("#" + subNaviItem + "_MNaviItem").addClass("active open");
}

function handleResponseForAlert(jsonResponse) {
	
	console.log(">>>>> handleResponseForAlert() called");
	
	if (jsonResponse != null) {
		
		var parsedResponse = JSON.parse(jsonResponse);		
		
		if (parsedResponse.ERROR != null) {
			
			console.log("----> ERROR response: " + parsedResponse.ERROR);
			
			var messageHTML = parsedResponse.ERROR;
			if (!messageHTML.includes("fa-exclamation-circle")) {
				messageHTML = "<i class=\"fa-lg fa fa-exclamation-circle\">&nbsp;&nbsp;</i>" + messageHTML;
			}
			
			$("#custom-alert-danger-message").html(messageHTML);
			$(".custom-alert-danger").show();
			
		}
		
		if (parsedResponse.WARNING != null) {
			
			console.log("----> WARNING response: " + parsedResponse.WARNING);
			
			var messageHTML = parsedResponse.WARNING;
			if (!messageHTML.includes("fa-exclamation-circle")) {
				messageHTML = "<i class=\"fa-lg fa fa-exclamation-circle\">&nbsp;&nbsp;</i>" + messageHTML;
			}
			
			$("#custom-alert-warning-message").html(messageHTML);
			$(".custom-alert-warning").show();
			
		}
		
		if (parsedResponse.SUCCESS != null) {
			
			console.log("----> SUCCESS response: " + parsedResponse.SUCCESS);
			
			var messageHTML = parsedResponse.SUCCESS;
			if (!messageHTML.includes("fa-check-circle")) {
				messageHTML = "<i class=\"fa-lg fa fa-check-circle\">&nbsp;&nbsp;</i>" + messageHTML;
			}
			
			$("#custom-alert-success-message").html(messageHTML);
			$(".custom-alert-success").show();
			
		}
		
		if (parsedResponse.INFO != null) {
			
			console.log("----> INFO response: " + parsedResponse.INFO);
			
			var messageHTML = parsedResponse.INFO;
			if (!messageHTML.includes("fa-info-circle")) {
				messageHTML = "<i class=\"fa-lg fa fa-info-circle\">&nbsp;&nbsp;</i>" + messageHTML;
			}
			
			$("#custom-alert-info-message").html(messageHTML);
			$(".custom-alert-info").show();
			
		}
		
	}
	
}

function hideAlertBoxes() {
	
	$("#custom-alert-info-message").html("");
	$(".custom-alert-info").hide();
	
	$("#custom-alert-success-message").html("");
	$(".custom-alert-success").hide();

	$("#custom-alert-warning-message").html("");
	$(".custom-alert-warning").hide();
	
	$("#custom-alert-danger-message").html("");
	$(".custom-alert-danger").hide();
	
}
